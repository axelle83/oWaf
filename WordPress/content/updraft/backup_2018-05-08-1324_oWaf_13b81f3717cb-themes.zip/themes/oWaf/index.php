<?php get_header(); ?>

<?php get_template_part('front-page'); ?>

<?php get_footer(); ?>
