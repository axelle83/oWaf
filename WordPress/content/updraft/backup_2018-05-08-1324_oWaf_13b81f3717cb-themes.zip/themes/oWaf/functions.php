<?php

require get_theme_file_path('inc/theme-support.php');

require get_theme_file_path('inc/theme-enqueue.php');

require get_theme_file_path('inc/theme-cleaner.php');

require get_theme_file_path('inc/customizer.php');
