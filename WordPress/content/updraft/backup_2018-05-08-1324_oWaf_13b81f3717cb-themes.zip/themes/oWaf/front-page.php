<?php get_header(); ?>

  <?php get_template_part('template-parts/image/entete') ?>

<section class="main">

  <?php get_template_part('sidebar'); ?>

  <?php get_template_part('template-parts/posts/posts-front-page'); ?>

</section>

<?php get_footer(); ?>
