<img  class="header__image" style="background-image: url(<?php header_image();  ?>);" >




<!-- <img src="<?php header_image(); ?>" height="<?php echo get_custom_header()->height; ?>" width="<?php echo get_custom_header()->width; ?>" alt="" /> -->
