
<?php wp_list_categories('title_li'); ?>
