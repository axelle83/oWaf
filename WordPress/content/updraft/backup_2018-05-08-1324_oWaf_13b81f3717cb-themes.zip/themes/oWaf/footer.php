<footer class="footer">
  <div class="footer__copyright">Copyright<span>oWaf</span>2018</div>
  <div class="footer__cgu"><a href="#">Nos conditions d'utilisation</a></div>
  <div class="footer__social">
    <a href=""><i class="fa fa-facebook-square"></i></a>
    <a href=""><i class="fa fa-twitter-square"></i></a>
  </div>
</footer>
</div>
<?php wp_footer(); ?>
</body>
