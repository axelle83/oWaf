document.addEventListener('DOMContentLoaded', function() {
  // do your setup here
  console.log('Initialized app');
});
