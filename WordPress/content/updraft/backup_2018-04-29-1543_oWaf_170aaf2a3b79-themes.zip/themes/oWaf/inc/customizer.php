<?php

// require get_theme_file_path('inc/customizer/section-carousel.php');
// require get_theme_file_path('inc/customizer/section-news.php');
//
// function oagency_customize_register($wp_customize)
// {
//   // Ajout d'un panel au customizer
//   $wp_customize->add_panel( 'oagency_theme_panel', [
//     'title' => '&#9733; oAgency &#9733;', // Notre titre
//     'description' => 'Panel de gestion pour le thème oAgency', // Description
//     'priority' => 1, // Emplacement dans le menu
//   ]);
//
//   create_section_carousel($wp_customize, 'oagency_theme_panel');
//   create_section_news($wp_customize, 'oagency_theme_panel');
// }
//
// add_action('customize_register', 'oagency_customize_register');
