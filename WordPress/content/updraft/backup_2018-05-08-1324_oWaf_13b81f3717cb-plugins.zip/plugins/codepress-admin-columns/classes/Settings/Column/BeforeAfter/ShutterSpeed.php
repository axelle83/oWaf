<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AC_Settings_Column_BeforeAfter_ShutterSpeed extends AC_Settings_Column_BeforeAfter {

	protected function define_options() {
		return array( 'before' => '', 'after' => 's' );
	}

}
