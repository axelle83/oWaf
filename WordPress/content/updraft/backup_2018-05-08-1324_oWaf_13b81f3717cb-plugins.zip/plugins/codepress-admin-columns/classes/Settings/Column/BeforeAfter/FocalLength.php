<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AC_Settings_Column_BeforeAfter_FocalLength extends AC_Settings_Column_BeforeAfter {

	protected function define_options() {
		return array( 'before' => '', 'after' => 'mm' );
	}

}
